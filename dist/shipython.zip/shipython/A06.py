#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Remove unique elements in the list.
#

ID = '01234'


def func( li ): # li: list
    # edit here
    return li


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( [ 3, 1, 2, 1, 3 ] )\n => {} ([ 3, 1, 1, 3 ])".format( func( [ 3, 1, 2, 1, 3 ] ) ) )
    print( "func( [ 4, 3, 2, 3 ] )\n => {} ([ 3, 3 ])".format( func( [ 4, 3, 2, 3 ] ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
