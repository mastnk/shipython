#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Multiply a and b
#

ID = '01234'


def func( a, b ): # a: int, b: int
    return 0


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( 'func( 3, 2 ) => {} (6)'.format( func( 3, 2 ) ) )
    print( 'func( 3, -1 ) => {} (-3)'.format( func( 3, -1 ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
