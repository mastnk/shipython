#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Calculate histgoram of frequency of characters in the text.
# 'Hello world.'
#  => {'H': 1, 'e': 1, 'l': 3, 'o': 2, ' ': 1, 'w': 1, 'r': 1, 'd': 1, '.': 1}
#


ID = '01234'


def func( text ): # text: string
    # edit here
    return {}


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( u'AAABBC' )\n => {} ({{'A': 3, 'B': 2, 'C': 1 }})".format( func( u'AAABBC' ) ) )
    print( "func( u'Hello world.' )\n => {} ({{'H': 1, 'e': 1, 'l': 3, 'o': 2, ' ': 1, 'w': 1, 'r': 1, 'd': 1, '.': 1}})".format( func( u'Hello world.' ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
