#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Encrypt the text by Caesar cipher.
#  n=2, 'This is a pen.' -> 'Vjku ku c rgp.'
#
#  https://en.wikipedia.org/wiki/Caesar_cipher

ID = '01234'


def func( text, n ): # text: string, n: int
    # edit here
    return text


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( 'This is a pen.', 2 )\n => {} ('Vjku ku c rgp.')".format( func( 'This is a pen.', 2 ) ) )
    print( "func( 'Hello, World.', -2 )\n => {} ('Fcjjm, Umpjb.')".format( func( 'Hello, World.', -2 ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
