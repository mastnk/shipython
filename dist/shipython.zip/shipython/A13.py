#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Calculate days between two dates.
# '1999/12/31', '2000/01/01' => 1
# '2000/01/01', '1999/12/31' => -1
#


ID = '01234'


def func( start, end ): # start: string('YYYY/MM/DD'), end: string('YYYY/MM/DD')
    # edit here
    return 0


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( '1999/12/31', '2000/01/01' )\n => {} (1)".format( func( '1999/12/31', '2000/01/01' ) ) )
    print( "func( '2000/01/01', '1999/12/31' )\n => {} (-1)".format( func( '2000/01/01', '1999/12/31' ) ) )
    print( "func( '2020/02/01', '2020/03/01' )\n => {} (29)".format( func( '2020/02/01', '2020/03/01' ) ) )
    print( "func( '2019/02/01', '2019/03/01' )\n => {} (28)".format( func( '2019/02/01', '2019/03/01' ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
