#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Find the second oldest person in dictionary.
#  { 'Alice': '2001/12/11', 'Bob': '1999/03/21', 'Camila': '2000/08/09', 'Daniel': '2000/10/10' }
#   => 'Camila'
#


ID = '01234'


def func( di ): # di: dictionary{ string: string }
    # edit here
    return ''


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( {{ 'Alice': '2001/12/11', 'Bob': '1999/03/21', 'Camila': '2000/08/09', 'Daniel': '2000/10/10' }} )\n => {} (Camila)".format( func( { 'Alice': '2001/12/11', 'Bob': '1999/03/21', 'Camila': '2000/08/09', 'Daniel': '2000/10/10' } ) ) )
    print( "func( {{ 'Alice': '2000/12/11', 'Bob': '2001/03/21', 'Camila': '2000/08/09', 'Daniel': '2001/11/11' }} )\n => {} (Alice)".format( func( { 'Alice': '2000/12/11', 'Bob': '2001/03/21', 'Camila': '2000/08/09', 'Daniel': '2001/11/11' } ) ) )



###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
