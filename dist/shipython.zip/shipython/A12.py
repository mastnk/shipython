#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Translate (row,colmun) to the excel-style cell identifier.
# (1,2) => 'B1'
#
# conditions: 1 <= row <= 500, 1 <= column <= 500
#


ID = '01234'


def func( row, column ): # row: int, column: int
    # edit here
    return ''


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( 1, 2 )\n => {} ('B1')".format( func( 1, 2 ) ) )
    print( "func( 20, 30 )\n => {} ('AD20')".format( func( 20, 30 ) ) )
    print( "func( 500, 500 )\n => {} ('SF500')".format( func( 500, 500 ) ) )

    print( func( 32, 100 ) )
    print( func( 16, 49 ) )
    print( func( 1, 499 ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
