#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Calculate the sum of the ASCII code of each character.
#

ID = '01234'


def func( str ): # str: string
    # edit here
    return 0


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( "func( u'Hi' ) => {} (177)".format( func( u'Hi' ) ) )
    print( "func( u'Hello' ) => {} (500)".format( func( u'Hello' ) ) )
    print( "func( u'Python' ) => {} (642)".format( func( u'Python' ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
