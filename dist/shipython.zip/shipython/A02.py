#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Find the second largest value in the list.
#

ID = '01234'


def func( li ): # li: list(int)
    return 0


###############################################################
# DO NOT EDIT BELOW
def sample( func ):
    print( 'func( [1,4,2,3] ) => {} (3)'.format( func( [1,4,2,3] ) ) )
    print( 'func( [5,6,7,8,9] ) => {} (8)'.format( func( [5,6,7,8,9] ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )


#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
