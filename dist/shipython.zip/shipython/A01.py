#!/usr/bin/env python
# -*- coding: utf-8 -*-

#
# Calculate the sum of the list.
#

ID = '01234'


def func( li ): # li: list(int)
    return 0

###############################################################
# DO NOT EDIT BELOW

def sample( func ):
    print( 'func( [1,2] ) => {} (3)'.format( func( [ 1, 2 ] ) ) )
    print( 'func( [4,8,12] ) => {} (24)'.format( func( [4,8,12] ) ) )


###############################################################
if( __name__ == '__main__' ):
    sample( func )

#################
# created by
#    name: Masayuki Tanaka
# twitter: http://twitter.com/likesilkto
#  github: http://github.com/mastnk
#     url: http://www.ok.sc.e.titech.ac.jp/~mtanaka/
